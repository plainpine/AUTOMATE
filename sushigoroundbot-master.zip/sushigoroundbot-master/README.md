sushigoroundbot
===============

A bot that plays the Sushi Go Round flash game using PyAutoGUI.

To use, install the PyAutoGUI module from https://pypi.python.org/pypi/PyAutoGUI or run 'sudo pip install pyautogui'

Load the Sushi Go Round game in a browser. It is available at http://miniclip.com/games/sushi-go-round/en/

Run the program with the game fully visible. Do not move the browser window while the game is playing.

To interrupt the program and regain control of the mouse, move the mouse to the top-left corner of your screen.

A gameplay video of the bot in action can be seen at https://youtu.be/lfk_T6VKhTE


Support
-------

If you find this project helpful and would like to support its development, [consider donating to its creator on Patreon](https://www.patreon.com/AlSweigart).
